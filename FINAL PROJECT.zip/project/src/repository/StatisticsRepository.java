package repository;

public class StatisticsRepository {
    //TODO: Your format to calculate employee salary
}
