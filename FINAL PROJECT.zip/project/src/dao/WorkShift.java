package dao;

public enum WorkShift {
    MORNING,
    AFTERNOON,
    NIGHT
}
