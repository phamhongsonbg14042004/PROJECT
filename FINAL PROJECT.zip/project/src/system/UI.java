package system;

import dao.Role;
import gui.LoginGUI;

public class UI {
    public LoginGUI loginGUI;

    public UI() {
        loginGUI = new LoginGUI();
    }

    public void changeToUser(Role role) {
        
    }
}
