
package gui;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class LoginGUI extends Application {

    private Authenticator authenticator = new Authenticator(); // Sử dụng lớp Authenticator mới

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Login App");

        // Set up grid layout
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        // Add login form components
        Label userLabel = new Label("Username:");
        TextField userTextField = new TextField();
        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();
        Button loginButton = new Button("Login");

        loginButton.setOnAction(e -> handleLogin(userTextField.getText(), passField.getText()));

        // Add components to grid
        gridPane.add(userLabel, 0, 0);
        gridPane.add(userTextField, 1, 0);
        gridPane.add(passLabel, 0, 1);
        gridPane.add(passField, 1, 1);
        gridPane.add(loginButton, 1, 2);

        // Show scene
        Scene scene = new Scene(gridPane, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void handleLogin(String username, String password) {
        String role = authenticator.authenticate(username, password);

        if (role == null) {
            showAlert("Error", "Invalid username or password!");
        } else if (role.equals("EMPLOYEE")) {
            showAlert("Welcome", "Welcome Employee! Limited access granted.");
            try {
                EmployeeManagementGUI employeeGUI = new EmployeeManagementGUI();
                employeeGUI.start(new Stage());
            } catch (Exception e) {
                showAlert("Error", "Failed to load Employee Management interface.");
            }
        } else if (role.equals("MANAGER")) {
            showAlert("Welcome", "Welcome Manager! Full access granted.");
            try {
                ManagerManagementGUI managerGUI = new ManagerManagementGUI();
                managerGUI.start(new Stage());
            } catch (Exception e) {
                showAlert("Error", "Failed to load Manager Management interface.");
            }
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}

// Lớp Authenticator mới để xử lý xác thực
class Authenticator {
    private java.util.Map<String, String> userCredentials = new java.util.HashMap<>();
    private java.util.Map<String, String> userRoles = new java.util.HashMap<>();

    public Authenticator() {
        // Example data
        userCredentials.put("employee", "password1");
        userRoles.put("employee", "EMPLOYEE");
        userCredentials.put("manager", "password2");
        userRoles.put("manager", "MANAGER");
    }

    public String authenticate(String username, String password) {
        if (userCredentials.containsKey(username) && userCredentials.get(username).equals(password)) {
            return userRoles.get(username);
        }
        return null;
    }
}